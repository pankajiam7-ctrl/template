// langgraph/nodes.js
import { generateText } from '../services/aiProvider.js'

// ─────────────────────────────────────────────────────────────
// SHARED BUDGET CALCULATOR
// ─────────────────────────────────────────────────────────────
const calcBudget = (budget, beneficiaries) => {
  const total     = parseInt(budget) || 500000
  const benefStr  = (beneficiaries || '10000').toString()
  const benefNum  = parseInt(benefStr.replace(/[^0-9]/g, '')) || 10000
  const personnel  = Math.round(total * 0.30)
  const activities = Math.round(total * 0.50)
  const training   = Math.round(total * 0.10)
  const meal       = Math.round(total * 0.06)
  const admin      = Math.round(total * 0.04)
  const perBenef   = Math.round(total / benefNum)
  const year1      = Math.round(total * 0.60)
  const year2      = Math.round(total * 0.40)
  return {
    total, personnel, activities, training,
    meal, admin, perBenef, year1, year2, benefNum,
    adminPct: Math.round(admin / total * 100),
    mealPct:  Math.round(meal  / total * 100),
  }
}

// ─────────────────────────────────────────────────────────────
// NODE 1 — Outline + Auto-generate details
// ─────────────────────────────────────────────────────────────
export const generateOutline = async (state) => {

  const b = calcBudget(state.budget, state.beneficiaries)

  const prompt = `
You are an expert NGO grant writer.
Generate structured proposal data and a 12-section outline.

NGO: ${state.ngo_name}
Topic: ${state.topic}
Region: ${state.region}
Donor: ${state.donor}
Duration: ${state.duration} months
Problem: ${state.problem}
Beneficiaries: ${state.beneficiaries}

LOCKED BUDGET — copy exactly, do NOT recalculate:
Total: USD ${b.total}
Personnel 30%: USD ${b.personnel}
Activities 50%: USD ${b.activities}
Training 10%: USD ${b.training}
MEAL 6%: USD ${b.meal}
Admin 4%: USD ${b.admin}
Per beneficiary: USD ${b.perBenef}
Year 1: USD ${b.year1}
Year 2: USD ${b.year2}

Return in EXACTLY this format:

BUDGET_BREAKDOWN:
Personnel USD ${b.personnel} — Project Manager USD ${Math.round(b.personnel*0.4)}, Field Officers x3 USD ${Math.round(b.personnel*0.4)}, Community Liaisons x2 USD ${Math.round(b.personnel*0.2)}.
Activities USD ${b.activities} — core project delivery, materials, equipment.
Training USD ${b.training} — community workshops x30 USD ${Math.round(b.training/30)} each, staff training.
MEAL USD ${b.meal} — Baseline M1 USD ${Math.round(b.meal/3)}, Midterm USD ${Math.round(b.meal/3)}, Endline M${state.duration} USD ${Math.round(b.meal/3)}.
Admin USD ${b.admin} — office, transport, communications. Admin rate ${b.adminPct}% below 9% ceiling.
TOTAL USD ${b.total}. Per beneficiary USD ${b.perBenef}. Sector average USD 45. Saving ${Math.round((45-b.perBenef)/45*100)}% below average.

SUSTAINABILITY:
Month 1: Form 20 community committees 60% women.
Month 3: Train 50 local staff in operations and management.
Month 6: Community-led monitoring system active.
Month 9: MOU signed with ${state.region} government — budget line secured.
Month 12: Community contribution covers 100% maintenance costs.
Month ${state.duration}: Full handover. Government absorbs 5 key staff. Alumni network formed.

BENEFICIARY_DETAILS:
Direct: ${b.benefNum} beneficiaries.
Women and girls 60%: ${Math.round(b.benefNum*0.6)}.
Men and boys 40%: ${Math.round(b.benefNum*0.4)}.
Children under 12: ${Math.round(b.benefNum*0.3)}.
From poorest households 60%: ${Math.round(b.benefNum*0.6)}.
Persons with disability 5%: ${Math.round(b.benefNum*0.05)}.
Indirect beneficiaries: ${b.benefNum*3} family and community members.

OUTLINE:
1. Executive Summary — USD ${b.total}, ${state.duration} months, ${b.benefNum} beneficiaries, problem, solution, donor alignment
2. Organization Profile — registration, past projects with numbers, team, credentials
3. Problem Statement — statistics, WHO benchmark, root causes, gap analysis
4. Objectives — 6 SMART objectives SDG linked, baseline and target values
5. Methodology — 4 phases month by month, community participation
6. Beneficiaries — ${b.benefNum} direct, ${b.benefNum*3} indirect, gender breakdown
7. Timeline — month by month milestones, Gantt table
8. Budget — line item table USD ${b.total}, per beneficiary USD ${b.perBenef}
9. MEAL — Theory of Change, 6 indicators table, baseline midterm endline
10. Risk Analysis — 6 risks, likelihood impact mitigation responsible monitoring
11. Sustainability — community ownership, government MOU, exit strategy
12. Annexures — registration, audits 3 years, CVs, letters of support
`

  const raw = await generateText(prompt, 2000)

  const budgetMatch  = raw.match(/BUDGET_BREAKDOWN:\n([\s\S]*?)(?=SUSTAINABILITY:)/)
  const sustainMatch = raw.match(/SUSTAINABILITY:\n([\s\S]*?)(?=BENEFICIARY_DETAILS:)/)
  const benefMatch   = raw.match(/BENEFICIARY_DETAILS:\n([\s\S]*?)(?=OUTLINE:)/)
  const outlineMatch = raw.match(/OUTLINE:\n([\s\S]*)/)

  const fallbackBudget = `Personnel USD ${b.personnel} — Project Manager USD ${Math.round(b.personnel*0.4)}, Field Officers x3 USD ${Math.round(b.personnel*0.4)}, Liaisons x2 USD ${Math.round(b.personnel*0.2)}. Activities USD ${b.activities}. Training USD ${b.training} — 30 workshops x USD ${Math.round(b.training/30)}. MEAL USD ${b.meal} — Baseline USD ${Math.round(b.meal/3)}, Midterm USD ${Math.round(b.meal/3)}, Endline USD ${Math.round(b.meal/3)}. Admin USD ${b.admin} — ${b.adminPct}% below 9% ceiling. TOTAL USD ${b.total}. Per beneficiary USD ${b.perBenef} vs sector USD 45 — ${Math.round((45-b.perBenef)/45*100)}% saving.`

  const fallbackSustain = `Month 1: Form 20 community committees 60% women. Month 3: Train 50 local staff. Month 6: Community monitoring system active. Month 9: MOU with ${state.region} government. Month 12: Community contributions cover 100% maintenance. Month ${state.duration}: Full government handover.`

  const fallbackBenef = `Direct ${b.benefNum}: Women 60% = ${Math.round(b.benefNum*0.6)}, Men 40% = ${Math.round(b.benefNum*0.4)}, Children under 12 = ${Math.round(b.benefNum*0.3)}, Poorest households = ${Math.round(b.benefNum*0.6)}, Disability = ${Math.round(b.benefNum*0.05)}. Indirect ${b.benefNum*3} community members.`

  return {
    outline:          outlineMatch  ? outlineMatch[1].trim()  : raw,
    budget_breakdown: budgetMatch   ? budgetMatch[1].trim()   : fallbackBudget,
    sustainability:   sustainMatch  ? sustainMatch[1].trim()  : fallbackSustain,
    beneficiaries:    benefMatch    ? benefMatch[1].trim()    : fallbackBenef,
    _budget:          b,
  }
}

// ─────────────────────────────────────────────────────────────
// NODE 2 — Full Proposal Generator
// ─────────────────────────────────────────────────────────────
export const generateProposal = async (state) => {

  const b = state._budget || calcBudget(state.budget, state.beneficiaries)

  const prompt = `
You are a senior NGO grant writer. Write a complete professional donor-ready proposal.

Donor: ${state.donor}
Follow this donor's known format and terminology exactly.

NGO: ${state.ngo_name}
Topic: ${state.topic}
Region: ${state.region}
Duration: ${state.duration} months
Problem: ${state.problem}
Beneficiaries: ${state.beneficiaries}
Budget Breakdown: ${state.budget_breakdown}
Sustainability Plan: ${state.sustainability}
Outline: ${state.outline}

LOCKED NUMBERS — COPY exactly. Do NOT recalculate, round, or reinterpret:
Total Budget: USD ${b.total}
Personnel: USD ${b.personnel}
Activities: USD ${b.activities}
Training: USD ${b.training}
MEAL Budget: USD ${b.meal}
Admin: USD ${b.admin}
Per Beneficiary: USD ${b.perBenef}
Sector Average: USD 45
Year 1: USD ${b.year1}
Year 2: USD ${b.year2}
Admin Rate: ${b.adminPct}%
Direct Beneficiaries: ${b.benefNum}
Indirect Beneficiaries: ${b.benefNum*3}

CRITICAL: Section 1, Section 6, Section 8 must show identical numbers.

REALISTIC TARGETS — use same values in Sections 1, 3, 4, 9:
Primary improvement: 60-80% not 100%.
Show baseline and target for each indicator.
Use WHO benchmark comparisons.

Section 1 — Executive Summary — 300 words
Include: USD ${b.total} request. ${state.duration} months. ${b.benefNum} direct beneficiaries. Core problem with statistics from input. Solution approach. Expected outcomes 60-80% improvement. Alignment with ${state.donor} priorities.

Section 2 — Organization Profile — 300 words
Registration details. Year founded. Past 3 projects with specific numbers and outcomes. Team expertise. Key partnerships. Delivery track record.

Section 3 — Problem Statement — 350 words
Use problem statistics exactly as provided in input. Compare to WHO or global benchmarks. Root causes. Gap analysis. Why this NGO is best placed. Do not claim 100% elimination.

Section 4 — Objectives — 300 words
Exactly 6 SMART objectives. Each linked to specific SDG number. Include baseline value, target value, and month deadline. Use 60-80% improvement. Format:
Objective 1: [target] by Month [X] — SDG [X.X] — Baseline [X] Target [Y]

Section 5 — Methodology — 400 words
Phase 1 M1-M${Math.round(parseInt(state.duration)*0.25)}: Baseline, community engagement, procurement.
Phase 2 M${Math.round(parseInt(state.duration)*0.25)}-M${Math.round(parseInt(state.duration)*0.60)}: Main delivery activities.
Phase 3 M${Math.round(parseInt(state.duration)*0.60)}-M${Math.round(parseInt(state.duration)*0.85)}: Training, monitoring.
Phase 4 M${Math.round(parseInt(state.duration)*0.85)}-M${state.duration}: Evaluation, handover, exit.
Community participation approach at each phase.

Section 6 — Beneficiaries — 250 words
Direct: ${b.benefNum}. Women ${Math.round(b.benefNum*0.6)}. Men ${Math.round(b.benefNum*0.4)}. Children ${Math.round(b.benefNum*0.3)}. Poorest households ${Math.round(b.benefNum*0.6)}. Disability ${Math.round(b.benefNum*0.05)}.
Indirect: ${b.benefNum*3}. Selection criteria. Vulnerability analysis. Geographic coverage.

Section 7 — Timeline — 200 words
Month by month milestones. Table with Month, Activity, Deliverable columns.

Section 8 — Budget — 350 words
Write this exact table — copy numbers exactly:
Category | Line Item | Qty | Unit Cost | Total USD
Personnel | Project Manager | 1 | ${Math.round(b.personnel*0.4/parseInt(state.duration))}/mo | ${Math.round(b.personnel*0.4)}
Personnel | Field Officers | 3 | ${Math.round(b.personnel*0.3/3/parseInt(state.duration))}/mo | ${Math.round(b.personnel*0.3)}
Personnel | Liaisons | 2 | ${Math.round(b.personnel*0.3/2/parseInt(state.duration))}/mo | ${Math.round(b.personnel*0.3)}
Activities | Core Delivery | - | - | ${b.activities}
Training | Workshops | 30 | ${Math.round(b.training/30)} | ${b.training}
MEAL | Evaluations | 3 | ${Math.round(b.meal/3)} | ${b.meal}
Admin | Operations | - | - | ${b.admin}
TOTAL | | | | ${b.total}

Year 1: USD ${b.year1}. Year 2: USD ${b.year2}.
Per beneficiary: USD ${b.perBenef} vs sector USD 45 — ${Math.round((45-b.perBenef)/45*100)}% below average.
Admin: ${b.adminPct}% — below 9% ceiling.

Section 9 — MEAL — 300 words
Theory of Change: Inputs to Activities to Outputs to Outcomes to Impact.
Indicator table:
Indicator | Baseline | Target | Timeline | Source
Primary outcome 1 | [from problem] | 60-80% improvement | M${state.duration} | Survey
Primary outcome 2 | [from problem] | measurable target | M${state.duration} | Records
Access or time indicator | [baseline] | [target] | M${Math.round(parseInt(state.duration)*0.75)} | Survey
Committees formed | 0 | 20 | M6 | Register
Staff trained | 0 | 50 | M12 | Training records
Contribution rate | 0% | 90% | M${Math.round(parseInt(state.duration)*0.75)} | Finance records
Baseline M1. Midterm M${Math.round(parseInt(state.duration)/2)}. Endline M${state.duration}. Independent external evaluator.

Section 10 — Risk Analysis — 300 words
Exactly 6 risks. For each:
Risk [N] — [Name] | Likelihood: H/M/L | Impact: H/M/L
Mitigation: [action with number or date]. Responsible: [role]. Monitoring: [frequency].
Include: climate, community resistance, budget overrun, staff turnover, government policy, supply chain.

Section 11 — Sustainability — 300 words
Use sustainability plan from input. Community ownership with timeline. Government integration. MOU details. Revenue or contribution model. Exit strategy. Post-project continuity.

Section 12 — Annexures — 150 words
NGO registration. Audited accounts 3 years. CVs key staff. Letters of support. Site maps. Baseline data report. Implementation schedule.

Writing rules:
COPY numbers exactly as given above. Do not recalculate.
Every claim backed by number. Every outcome has metric.
Write in ${state.language}. Professional and formal tone.
`
  const proposal = await generateText(prompt, 4000)
  return { proposal }
}

// ─────────────────────────────────────────────────────────────
// NODE 3 — Evaluator
// ─────────────────────────────────────────────────────────────
export const evaluateProposal = async (state) => {

  const b = state._budget || calcBudget(state.budget, state.beneficiaries)

  const proposalText = state.proposal || ''
  const execMatch    = proposalText.match(/Section 1[\s\S]{0,1500}(?=Section 2)/)
  const budgetMatch  = proposalText.match(/Section 8[\s\S]{0,1500}(?=Section 9)/)
  const mealMatch    = proposalText.match(/Section 9[\s\S]{0,1000}(?=Section 10)/)
  const riskMatch    = proposalText.match(/Section 10[\s\S]{0,1000}(?=Section 11)/)
  const sustainMatch = proposalText.match(/Section 11[\s\S]{0,800}(?=Section 12)/)

  const execSection    = execMatch    ? execMatch[0]    : proposalText.slice(0, 800)
  const budgetSection  = budgetMatch  ? budgetMatch[0]  : proposalText.slice(-2000, -1200)
  const mealSection    = mealMatch    ? mealMatch[0]    : proposalText.slice(-1200, -400)
  const riskSection    = riskMatch    ? riskMatch[0]    : ''
  const sustainSection = sustainMatch ? sustainMatch[0] : ''

  const prompt = `
You are a strict grant evaluator at ${state.donor || 'an international donor'}.
Give a realistic honest score.

EXECUTIVE SUMMARY:
${execSection}

BUDGET SECTION:
${budgetSection}

MEAL SECTION:
${mealSection}

RISK SECTION:
${riskSection}

SUSTAINABILITY:
${sustainSection}

Expected values:
Total budget: USD ${b.total}
Per beneficiary: USD ${b.perBenef}
Beneficiaries: ${b.benefNum}
Donor: ${state.donor}

Clarity 0-25: Clear structure, specific language, zero ambiguity.
Feasibility 0-25: Realistic timeline, budget matches activities.
Impact 0-30: Metrics clear, SDG linked, gender shown, baseline and targets.
Budget Fit 0-20: Line items, per beneficiary cost, VfM, admin under 9%.

Deduct ONLY if actually missing:
Generic language: minus 3
No statistics: minus 3
No budget table: minus 5
Donor format missing: minus 4
Sustainability missing: minus 3
No risk mitigation: minus 3
No MEAL indicators: minus 4
Vague phrases committed to or dedicated to: minus 2 each

Do NOT deduct if present:
MEAL indicator table present → no MEAL deduction
6 risks with mitigation → no risk deduction
Budget line item table → no budget deduction
Numbers throughout → no generic deduction
Sustainability timeline → no sustainability deduction

Add points:
Local partnership: plus 2
Government alignment: plus 2
WHO or global evidence: plus 2
Innovation angle: plus 2

Guide: Average 55-65. Good 70-80. Excellent 82-90. Outstanding 91-95.

Return ONLY valid JSON. No markdown. No text before or after:
{
  "clarity": 0,
  "feasibility": 0,
  "impact": 0,
  "budget_fit": 0,
  "total": 0,
  "grade": "Excellent or Good or Average or Poor",
  "feedback": "3-4 specific lines",
  "strengths": ["strength 1", "strength 2", "strength 3"],
  "weaknesses": ["weakness 1", "weakness 2"],
  "deductions": ["reason 1", "reason 2"],
  "improvements": ["fix 1", "fix 2"]
}
`
  const raw = await generateText(prompt, 1000)

  let result = {
    clarity: 0, feasibility: 0, impact: 0,
    budget_fit: 0, total: 0, grade: 'N/A',
    feedback: '', strengths: [], weaknesses: [],
    deductions: [], improvements: []
  }

  try {
    const jsonStart = raw.indexOf('{')
    const jsonEnd   = raw.lastIndexOf('}')
    if (jsonStart !== -1 && jsonEnd !== -1) {
      result = JSON.parse(raw.slice(jsonStart, jsonEnd + 1))
    }
  } catch {
    result.feedback = 'Evaluation parsing failed'
    result.total    = 70
  }

  return {
    score:     result.total,
    feedback:  result.feedback,
    breakdown: result
  }
}

// ─────────────────────────────────────────────────────────────
// NODE 4 — Generic Check
// ─────────────────────────────────────────────────────────────
export const checkGeneric = async (state) => {
  const prompt = `
Check if this NGO proposal is specific or generic.

Proposal:
${(state.proposal || '').slice(0, 1500)}

Inputs:
NGO: ${state.ngo_name}
Region: ${state.region}
Problem: ${state.problem}
Donor: ${state.donor}

Check:
1. Is NGO name ${state.ngo_name} mentioned?
2. Is region ${state.region} mentioned?
3. Are real numbers from problem used?
4. Is donor ${state.donor} format followed?
5. Is problem specific to this community?

Return ONLY valid JSON. No markdown. No extra text:
{
  "is_generic": false,
  "generic_score": 15,
  "checks": {
    "ngo_mentioned": true,
    "region_specific": true,
    "real_numbers": true,
    "donor_format": true,
    "problem_specific": true
  },
  "generic_issues": [],
  "verdict": "Specific"
}
`
  const raw = await generateText(prompt, 500)

  try {
    const jsonStart = raw.indexOf('{')
    const jsonEnd   = raw.lastIndexOf('}')
    const result    = JSON.parse(raw.slice(jsonStart, jsonEnd + 1))
    return { generic_check: result }
  } catch {
    return {
      generic_check: {
        is_generic: false,
        generic_score: 0,
        verdict: 'Check failed',
        checks: {},
        generic_issues: []
      }
    }
  }
}