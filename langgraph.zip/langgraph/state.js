// langgraph/state.js
// Shared state dictionary — flows through all 3 nodes

export const proposalState = {
  // ── User inputs ───────────────────────────────────
  topic: { value: (a, b) => b ?? a, default: () => '' },
  ngo_name: { value: (a, b) => b ?? a, default: () => '' },
  region: { value: (a, b) => b ?? a, default: () => '' },
  budget: { value: (a, b) => b ?? a, default: () => '' },
  duration: { value: (a, b) => b ?? a, default: () => '' },
  language: { value: (a, b) => b ?? a, default: () => 'English' },
  donor: { value: (a, b) => b ?? a, default: () => '' },
  problem: { value: (a, b) => b ?? a, default: () => '' },

  // ── Node 1 output ─────────────────────────────────
  outline: { value: (a, b) => b ?? a, default: () => '' },

  // ── Node 2 output ─────────────────────────────────
  proposal: { value: (a, b) => b ?? a, default: () => '' },

  // ── Node 3 output ─────────────────────────────────
  score: { value: (a, b) => b ?? a, default: () => 0 },
  feedback: { value: (a, b) => b ?? a, default: () => '' },
  breakdown: { value: (a, b) => b ?? a, default: () => ({}) },
  generic_check: { value: (a, b) => b ?? a, default: () => ({}) },
  budget_breakdown: { value: (a, b) => b ?? a, default: () => '' },
  sustainability: { value: (a, b) => b ?? a, default: () => '' },
}

// yeh line add karo baaki keys ke saat