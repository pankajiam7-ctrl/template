// langgraph/graph.js
import { StateGraph, END } from '@langchain/langgraph'
import { proposalState } from './state.js'
import {
    generateOutline,
    generateProposal,
    evaluateProposal,
    checkGeneric
} from './nodes.js'

const graph = new StateGraph({ channels: proposalState })

// Node names alag rakho state keys se
graph.addNode('node_outline', generateOutline)    // 'outline' nahi
graph.addNode('node_proposal', generateProposal)   // 'proposal' nahi
graph.addNode('node_evaluate', evaluateProposal)   // 'evaluate' nahi
graph.addNode('node_generic', checkGeneric)       // 'generic' nahi

graph.setEntryPoint('node_outline')
graph.addEdge('node_outline', 'node_proposal')
graph.addEdge('node_proposal', 'node_evaluate')
graph.addEdge('node_evaluate', 'node_generic')
graph.addEdge('node_generic', END)

export const proposalGraph = graph.compile()